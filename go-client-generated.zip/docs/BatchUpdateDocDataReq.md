# BatchUpdateDocDataReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FileID** | **string** |  | [default to null]
**Requests** | [**[]Request**](Request.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

