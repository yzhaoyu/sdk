# Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GetDocFullTextRsp** | [***GetDocFullTextRsp**](GetDocFullTextRsp.md) |  | [optional] [default to null]
**BatchUpdateDocDataRsp** | [***BatchUpdateDocDataRsp**](BatchUpdateDocDataRsp.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

