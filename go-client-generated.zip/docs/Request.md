# Request

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InsertText** | [***InsertTextRequest**](InsertTextRequest.md) |  | [optional] [default to null]
**InsertImage** | [***InsertImageRequest**](InsertImageRequest.md) |  | [optional] [default to null]
**InsertWebBlock** | [***InsertWebBlockRequest**](InsertWebBlockRequest.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

