# Node

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Begin** | **int32** |  | [optional] [default to null]
**End** | **int32** |  | [optional] [default to null]
**Type_** | **string** |  | [optional] [default to null]
**Children** | [**[]Node**](Node.md) |  | [optional] [default to null]
**Text** | **string** |  | [optional] [default to null]
**Property** | [**map[string]Object**](.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

