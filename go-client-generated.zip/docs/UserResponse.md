# UserResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ret** | **int32** |  | [optional] [default to null]
**Msg** | **string** |  | [optional] [default to null]
**Data** | [***Response**](Response.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

